const placar = {
    altura:30,
    corFundo:"black",
    corTexto:"white",
    pts: 0,
    
    desenhar(){
        ctx.fillStyle = this.corFundo;
        ctx.fillRect(0,0,canvas.width, canvas.height);
        ctx.fillStyle = this.corTexto;
        ctx.textAlign="left";
        ctx.font="14px Fantasy"
        ctx.fillText(this.pts + " ponto(s)",100,3*this.altura/4);

        ctx.textAlign = "center"
        ctx.fillText(this.nomeJogo, 800,3*this.altura/4);
        
        ctx.textAlign="right";
        ctx.fillText(cobra.vida + " vida(s)",canvas.width-100,3*this.altura/4);
    }
}
