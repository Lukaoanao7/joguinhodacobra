class Alimento extends ObjetoJogo {

    img=[ "\img\\sapoBranco.png", "\img\\sapoAmarelo.png", "\img\\sapoLaranja.png", "\img\\sapoAzul.png", "\img\\sapoVerde.png" ];
    imagem;
    constructor(valor,...args){
        super(args);
        this.valor=valor;
        this.imagem = new Image();
        this.imagem.src = this.img[Math.floor(Math.random() * this.img.length)];
    };
    desenhar(){
        ctx.drawImage(this.imagem, this.x, this.y
                      , this.tamanho, this.tamanho);
    }
}
